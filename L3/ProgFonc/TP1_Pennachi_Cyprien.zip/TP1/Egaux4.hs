egaux4 :: Eq a => a -> a -> a -> a -> Bool
egaux4 a b c d = a == b && b == c && c == d