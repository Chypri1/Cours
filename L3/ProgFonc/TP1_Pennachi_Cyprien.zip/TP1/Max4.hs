max4 :: Ord a => a -> a -> a -> a -> a
max4 a b c d = max (max a b) (max c d)